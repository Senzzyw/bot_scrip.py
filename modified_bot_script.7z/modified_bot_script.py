
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext, JobQueue
import time
import re

# Masukkan Token dari BotFather dan ID Telegram Anda
TOKEN = '7884553846:AAGK-v9v0lWQ1qF4pJv9XYYDQUtITjpnMqY'
ADMIN_ID = 6051866546  # ID Telegram Anda

# Jeda auto sebar (dalam detik)
delay = 30
running = False
sebar_text = "Pesan auto sebar"  # Pesan default

# Fungsi untuk mengirim pesan berulang menggunakan JobQueue
def auto_sebar_job(context: CallbackContext):
    grup_id = context.job.context
    context.bot.send_message(chat_id=grup_id, text=sebar_text)
    print(f"Pesan terkirim ke grup ID {grup_id}")

# Memulai auto sebar menggunakan JobQueue
def start_auto(update: Update, context: CallbackContext) -> None:
    if update.effective_user.id != ADMIN_ID:
        update.message.reply_text("Anda tidak memiliki izin untuk mengakses perintah ini.")
        return

    global running
    if not running:
        running = True
        update.message.reply_text("Auto sebar diaktifkan.")
        job_queue = context.job_queue
        for grup_id in context.bot_data.get('groups', []):
            job_queue.run_repeating(auto_sebar_job, interval=delay, first=0, context=grup_id)
    else:
        update.message.reply_text("Auto sebar sudah aktif.")

# Menghentikan auto sebar
def stop_auto(update: Update, context: CallbackContext) -> None:
    if update.effective_user.id != ADMIN_ID:
        update.message.reply_text("Anda tidak memiliki izin untuk mengakses perintah ini.")
        return

    global running
    if running:
        running = False
        # Hapus semua pekerjaan di JobQueue
        context.job_queue.stop()
        update.message.reply_text("Auto sebar dinonaktifkan.")
    else:
        update.message.reply_text("Auto sebar sudah nonaktif.")

# Mengatur pesan sebar
def set_sebar_text(update: Update, context: CallbackContext) -> None:
    if update.effective_user.id != ADMIN_ID:
        update.message.reply_text("Anda tidak memiliki izin untuk mengakses perintah ini.")
        return

    global sebar_text
    new_text = ' '.join(context.args)
    if new_text:
        sebar_text = new_text
        update.message.reply_text(f"Pesan auto sebar diubah menjadi: {sebar_text}")
    else:
        update.message.reply_text("Silakan masukkan teks baru setelah perintah.")

# Fungsi untuk mendeteksi link grup dan otomatis bergabung
def handle_group_link(update: Update, context: CallbackContext) -> None:
    if update.effective_user.id != ADMIN_ID:
        update.message.reply_text("Anda tidak memiliki izin untuk mengakses perintah ini.")
        return

    link = update.message.text
    group_link_pattern = r"(https://t\.me/joinchat/[\w-]+)"
    match = re.search(group_link_pattern, link)
    if match:
        try:
            invite_link = match.group(1)
            chat = context.bot.join_chat(invite_link)
            grup_id = chat.id
            if grup_id not in context.bot_data.setdefault('groups', []):
                context.bot_data['groups'].append(grup_id)
                update.message.reply_text(f"Bot berhasil bergabung ke grup {chat.title} dan akan mulai sebar pesan.")
                context.job_queue.run_repeating(auto_sebar_job, interval=delay, first=0, context=grup_id)
            else:
                update.message.reply_text("Bot sudah berada di grup tersebut.")
        except Exception as e:
            update.message.reply_text(f"Error bergabung ke grup: {e}")

# Konfigurasi bot
def main():
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start_auto", start_auto))
    application.add_handler(CommandHandler("stop_auto", stop_auto))
    application.add_handler(CommandHandler("set_text", set_sebar_text))
    application.add_handler(MessageHandler(filters.Regex(r"(https://t\.me/joinchat/[\w-]+)"), handle_group_link))

    application.run_polling()

if __name__ == '__main__':
    main()
